///
/// @file 
/// @brief Duffing Oscillator ODE solver using RK
/// @author 3-Body Problem based on file by Bob Hirosky
/// @date 14 Jan 2020 
/// 
/// Use the Rk4 solver for Duffing Oscillator
///
/// Definition of our variables
/// x    = time <br>
///

#include "runge-kutta/RKn.hpp"
#include "TROOT.h"
#include "TApplication.h"
#include "TLegend.h"
#include "TFile.h"
#include "TStyle.h"
#include "TGClient.h"
#include "TF1.h"
#include "TCanvas.h"
#include "TGraph.h"
#include <iostream>
#include <math.h>
#include "TAxis.h"
using namespace std;


//--------------------------------------------
// Define Constants and parameter values
const double m = 1;
const double a = 0.5;
const double b = 0.25;
double F_0 = 2.0;
double omega = 2.4;
double g = 0.1;
double x_0 = 0.5;
double x_0_dot = 0;
double x_max = 50;
int nsteps = 2500000;
/// \brief Change in position along \f$\hat i\f$ axis
/// \param[in] x independent variable
/// \param[in] y dependent variables
double f_ri(double x, const vector<double> &y){ 
  (void) x;   // prevent unused variable warning
  return y[1];
}

/// \brief Change in velocity along  \f$\hat i\f$ axis
/// \param[in] x independent variable
/// \param[in] y dependent variables
double f_vi(double x, const vector<double> &y){ 
  (void) x;
  return (-1 * g * y[1] / m) + (2 * a * y[0] / m) - (4 * b * pow(y[0], 3) / m) + (F_0 * cos(omega * x) / m);
}

/// \brief Stopping condition
/// \param[in] x independent variable
/// \param[in] y dependent variables
///
/// Returns 0(1) to flag continuation(termination) of calculation 
double f_stop(double x, const vector<double> &y){
  (void) x;
  if (x < x_max) 
    return 0;  
  return 1;
}

//Find the fractal dimension
void fractDimFinder(double xVals[], double yVals[], int nSteps){
 
  int numLs = 7;
  double logb[numLs];
  double logN[numLs];
  int step = 0;
  for (int l = 2; l <= 128; l *= 2)
    {
      int **cells = new int*[l];
      
      for (int c = 0; c< l; c++)
	cells[c] = new int[l];

      for (int i = 0; i < l; i++)
	{
	  for (int j = 0; j < l; j++)
	    cells[i][j] = 0;
	}

      int count = 0;
      
      double sideLen = 6.0 / l;
      for (int s = 0; s < nSteps; s++)
	{
	  
	  //Convert (x,y) -> cell x and ys
	  int cellX = int(round((xVals[s] + 3) / sideLen)) - 1; 
	  int cellY = int(round((yVals[s] + 3) / sideLen)) - 1;
	  
	  if(cellX < 0)
	    cellX = 0;
	  if(cellY < 0)
	    cellY = 0;
	 
	      
	  if (cells[cellY][cellX] == 0)
	    {
	      cells[cellY][cellX] = 1;
	      count++;
	    }
	}
      
      cout << "N(b) = " << count << " for b=" << sideLen << " and l^2=" << l*l<< endl;
      logb[step] = -log(sideLen);
      logN[step] = log(count);
      step++;
   
      for (int i = 0; i < l; i++)
	{
	  /*
	  for (int j = 0; j < l; j++)
	    cout << cells[i][j] << " ";
	    cout << "\n";*/
	  delete cells[i];
	  }
      delete cells;
    }


  TGraph *dimGraph = new TGraph(numLs, logb, logN);
  dimGraph->SetTitle("Log(N(b)) over Log(b)");
  dimGraph->GetYaxis()->SetTitle("Log(N(b))");
  dimGraph->GetXaxis()->SetTitle("Log(b)");
  TCanvas *dimCanv = new TCanvas("dimCanv", "Fractal Dimension Finding", 800, 600);
  dimGraph->Fit("pol1");
  dimCanv->cd();
  dimGraph->Draw();
				

}
/// \brief
int main(int argc, char **argv){
  TApplication theApp("App", &argc, argv); // init ROOT App for displays


  // ******************************************************************************
  // ** this block is useful for supporting both high and std resolution screens **
  UInt_t dh = gClient->GetDisplayHeight()/2;   // fix plot to 1/2 screen height  
  //UInt_t dw = gClient->GetDisplayWidth();
  UInt_t dw = 1.1*dh;
  // ******************************************************************************
  TCanvas *c1 = new TCanvas("c1","Strange Attractor",dw,dh);
  

  // *** test 2: Use RK4SolveN to calculate simple projectile motion
  vector<pfunc_t> v_fun(2);   // 4 element vector of function pointers
  v_fun[0]=f_ri;
  v_fun[1]=f_vi;
  vector<double> y0(2);
  // initial conditions are starting position, velocity and angle, equivalently ri,rj,vi,vj
  y0[0]=x_0;   // init position on i-axis
  y0[1]=x_0_dot;  // init velocity along i axis
  auto tgN = RK4SolveN(v_fun, y0, nsteps, 0, x_max, f_stop);
  TCanvas *c2 = new TCanvas("c2","ODE solutions 2",dw,dh);

  tgN[0].Draw("a*");
  c2->Draw();
  /*// save our graphs
  TFile *tf=new TFile("RKnDemo.root","recreate");
  for (unsigned i=0; i<v_fun.size(); i++){
    tgN[i].Write();
  }

  tf->Close(); */
  x_max = 25000;
  omega = 2.4;
  F_0 = 2;
  g = 0.1;
  double t=0;
  double h=x_max/nsteps;  // step size
  // printf("%d\n",(int)floor(nsteps/(2*M_PI/omega))+1);
  double vvals[1000000];
  double xvals[1000000];
  vector<double> y(2);
  y[0] = 0.5;
  y[1] = 0;
  int counter = 0;
  do {
    if((t/(2*M_PI/omega) - (int)(t/(2*M_PI/omega))) < h) {
      //printf("%lf, %lf, %lf, %lf\n",t, M_PI, omega, h);
      //printf("%lf\n",remainder(t,(2*M_PI/omega)));
      vvals[counter] = y[1];
      xvals[counter] = y[0];
      counter++;
      //printf("%d\n",counter);
    }
    y=RK4StepN(v_fun,y,t,h);
    t+=h;
  } while (f_stop(t,y)==0);
  //printf("%d\n",counter);
  TGraph *g = new TGraph(counter,xvals,vvals);
  g->SetTitle("Momentum over Position");
  g->GetYaxis()->SetTitle("p(t)");
  g->GetXaxis()->SetTitle("x(t)");
  c1->cd();
  g->Draw("a*");

  fractDimFinder(xvals, vvals, counter);
  
  cout << "Press ^c to exit" << endl;
  theApp.Run();
}

