//Solve Duffing Oscillator ODE using GSL
//3-Body Problem

#include <gsl/gsl_errno.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_odeiv2.h>
#include "TROOT.h"
#include "TApplication.h"
#include "TLegend.h"
#include "TFile.h"
#include "TStyle.h"
#include "TGClient.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TAxis.h"
#include <cstdio>

const double m = 1;
const double a = 0.5;
const double b = 0.25;
double F_0 = 2.0;
double omega = 2.4;
double g = 0.1;

int funct(double x, const double y[], double f[], void *params){ 
  (void) x;
  f[0] = y[1];
  f[1] = (-1 * g * y[1] / m) + (2 * a * y[0] / m) - (4 * b * pow(y[0], 3) / m) + (F_0 * cos(omega * x) / m);
  
  return GSL_SUCCESS; 
}


int main(int argc, char *argv[])
{
  //Second param is Jacobian which we don't need b/c using explicit solver, third is dimension, fourth uneeded mu
  gsl_odeiv2_system syst = {funct, NULL, 2, NULL};
  //Currently uses the RK4 stepper type
  gsl_odeiv2_driver *driver = gsl_odeiv2_driver_alloc_y_new(&syst, gsl_odeiv2_step_rk4, 1e-6, 1e-6, 0);

  double t = 0; //Time/step boundaries
  double tMax = 50;
  const int N_STEPS = 1000;
  double stepSize = tMax / N_STEPS;
  double y[2] = {0.5, 0}; //Initial conditions

  //Plotting Objects
  TApplication theApp("App", &argc, argv); // init ROOT App for displays
  TCanvas *canv = new TCanvas("canv", "GSL Duffing Oscillator", 800, 600);

  double xs[N_STEPS];
  double ys[N_STEPS];
  

  for (int s = 0; s < N_STEPS; s++)
    {
      double t_s = s * stepSize;

      int status = gsl_odeiv2_driver_apply(driver, &t, t_s, y); //Take the next step

      if (status != GSL_SUCCESS)
	{
	  printf("%s","Error: Consult the nearest fluffy squirrel for help");
	  break;
	}
      xs[s] = t;
      ys[s] = y[0];
      
    }

  TGraph *graph = new TGraph(N_STEPS, xs, ys);
  graph->SetTitle("Duffing Oscillator Solution;Time;Position");
  graph->Draw();
  canv->Update();

  gsl_odeiv2_driver_free(driver);
  theApp.Run();

  return 0;
}
