///
/// @file 
/// @brief DLA cluster simulation
/// @author 3-Body Problem
/// @date 16 Jan 2020 

#include "TROOT.h"
#include "TApplication.h"
#include "TLegend.h"
#include "TFile.h"
#include "TStyle.h"
#include "TGClient.h"
#include "TF1.h"
#include "TCanvas.h"
#include "TGraph.h"
#include <iostream>
#include <fstream>
#include <math.h>
#include "TAxis.h"
#include <time.h>

using namespace std;

const int nSitesMax = 9000;
const int nX = 200 + 2; // pad the edges to make stopping condition simpler
const int nY = 200 + 2;
int lattice[nX][nY] = {0};


// Places a random walker on the perimeter of a 150x150 lattice
void initialize(int *rx, int *ry) {
  // z selects edge
  int z = rand() % 4;
  
  if (z == 0) {
    *rx = rand() % (nX - 2) + 1;
    *ry = 1;
  } else if (z == 1) {
    *rx = nX - 2;
    *ry = rand() % (nY - 2) + 1;
  } else if (z == 2) {
    *rx = rand() %(nY - 2) + 1;
    *ry = nY - 2;
  } else {
    *rx = 1;
    *ry = rand() % (nX - 2) + 1;
  }
}

// Returns 1 if a neighbor site is occupied
int stopCond(int rx, int ry) {
  return (lattice[rx+1][ry] || lattice[rx-1][ry]
       || lattice[rx][ry+1] || lattice[rx][ry-1]);
}

void step(int *rx, int *ry) {
  int z, rxNew, ryNew;
  z = rand()%4;
  rxNew = *rx;
  ryNew = *ry;
  
  if      (z == 0) rxNew++;
  else if (z == 1) rxNew--;
  else if (z == 2) ryNew++;
  else             ryNew--;
  
  // In order to not step on or outside the padding
  if ((rxNew >= 1 && rxNew <= nX - 2 && ryNew >= 1 && ryNew <= nY - 2)) {
    *rx = rxNew;
    *ry = ryNew;
  }
}


int main(int argc, char **argv) {
  TApplication theApp("App", &argc, argv);

  UInt_t dh = gClient->GetDisplayHeight() / 2;
  UInt_t dw = dh;
  TCanvas *tc1 = new TCanvas("c1","Diffusion limited aggregation",dw,dh);
  TCanvas *tc2 = new TCanvas("c2","Diffusion limited aggregation",dw,dh);

  // Arrays for points in the lattice for the TGraph
  double x[nSitesMax];
  double y[nSitesMax];
  double logR[nSitesMax/200];
  double logN[nSitesMax/200];
  
  //FILE *fp = fopen("logR_logN.dat", "w");
  //fprintf(fp, "# log(Rg) log(N)\n");
  srand(time(0));
  lattice[nX/2][nY/2] = 1;
  
  int rx, ry;
  // Sum is the sum of r.r for each site
  double r0  = 0;
  double r0x = 0;
  double r0y = 0;
  double Rg2;
  double sum = 0;
  int nSites = 0;
  
  while (nSites < nSitesMax) {
    initialize(&rx, &ry);
    
    while (!stopCond(rx, ry)) step(&rx, &ry);
    
    x[nSites] = rx;
    y[nSites] = ry;
    nSites++;
    lattice[rx][ry] = 1;
    r0x += rx-nX/2;
    r0y += ry-nY/2;
    r0   = sqrt(r0x*r0x + r0y*r0y);
    r0  /= nSites;
    sum += ((rx-nX/2)*(rx-nX/2) + (ry-nY/2)*(ry-nY/2)) / nSites;
    
    if (nSites % 200 == 0 && nSites != 0) {
      Rg2 = sum - r0*r0;
      logR[nSites/200-1] = 0.5*log(Rg2);
      logN[nSites/200-1] = log(nSites);
      //fprintf(fp, "%f %f\n", 0.5*log(Rg2), log(nSites));
    }
  }
  
  //fclose(fp);

  //ofstream file;
  //file.open("lattice.dat");
  //file << "# x y\n";
  /*for (int i = 0; i < nX; i++) {
    for (int j = 0; j < nY; j++) {
      if (lattice[i][j] == 1) file << i << " " << j << endl;
    }
  }*/

  TGraph *tg1 = new TGraph(nSites, x, y);
  TGraph *tg2 = new TGraph(nSites/200, logR, logN);
  tg1->SetTitle("DLA Cluster with 9000 Sites;x;y");
  tg1->GetYaxis()->SetTitle("Y position");
  tg1->GetXaxis()->SetTitle("X position");
  tg2->GetYaxis()->SetTitle("Log(N)");
  tg2->GetXaxis()->SetTitle("Log(Rg)");
  tg2->SetTitle("Number of Sites vs Radius of Gyration");
  tc1->cd();
  tg2->Fit("pol1");
  double m = tg2->GetFunction("pol1")->GetParameter(1);
  printf("Dimension = %f\n", m);
  tg1->Draw("ap*");
  tc2->cd();
  tg2->Draw("ac*");
  tc1->Draw();
  tc2->Draw();

  cout << "Press ^c to exit" << endl;
  theApp.Run();
  
  return 0;
}
